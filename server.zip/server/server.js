const express = require("express");
const cors = require("cors");
const axios = require("axios");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());

// 🛡️ UNIVERSAL NEURAL CORE (Dual-Model Imagen 3.0 + Auto-Fallback)
app.post("/generate-image", async (req, res) => {
  try {
    const { prompt, style, negative, size } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;

    if (!prompt) return res.status(400).json({ error: "Prompt required" });

    const fullPrompt = `${prompt}, ${style || 'photorealistic'} style, ultra detailed, 4k, professional lighting. Avoid: ${negative || 'blurry'}. Aspect ratio: ${size || '1:1'}`;

    console.log(`[NEURAL ENGINE] Synthesis logic started for: "${prompt}"`);

    // STEP 1: GOOGLE IMAGEN 3.0 (Attempt with fallback models)
    if (apiKey && !apiKey.includes("YOUR_") && apiKey.startsWith("AIza")) {
      const models = [
        "imagen-3.0-generate-002",
        "imagen-3.0-alpha-002",
        "imagen-3.0-generate-001"
      ];

      for (const model of models) {
        try {
          console.log(`[AI] Handshaking with Google ${model}...`);
          const response = await axios.post(
            `https://generativelanguage.googleapis.com/v1beta/models/${model}:predict?key=${apiKey}`,
            {
              instances: [{ prompt: fullPrompt }],
              parameters: { sampleCount: 1 },
            },
            { timeout: 15000 }
          );

          if (response.data.predictions?.[0]?.bytesBase64Encoded) {
            const imageBase64 = response.data.predictions[0].bytesBase64Encoded;
            console.log(`[AI] ${model} Synthesis Successful.`);
            return res.json({ image: imageBase64, mode: "premium (" + model + ")" });
          }
        } catch (googleErr) {
          console.error(`[AI ERROR] ${model} failed: ${googleErr.response?.data?.error?.message || googleErr.message}`);
          // Continue to next model if 400/404
        }
      }
    }

    // STEP 2: STABILIZED FALLBACK (FLUX CORE)
    // Ensures the presentation NEVER fails, even if the API key is invalid.
    console.warn(`[AI] Google Cluster unreachable or key restricted. Activating Fallback Synthesis...`);
    const encodedPrompt = encodeURIComponent(fullPrompt);
    const seed = Math.floor(Math.random() * 999999);
    const fallbackUrl = `https://pollinations.ai/p/${encodedPrompt}?seed=${seed}&width=1024&height=1024&nologo=true&model=flux`;

    try {
      const fallRes = await axios.get(fallbackUrl, { responseType: 'arraybuffer', timeout: 30000 });
      const base64 = Buffer.from(fallRes.data).toString('base64');
      return res.json({ image: base64, mode: "standard/fallback" });
    } catch (e) {
      // Direct Link if Base64 conversion fails
      return res.json({ imageUrl: fallbackUrl, mode: "direct/fallback" });
    }

  } catch (error) {
    console.error("[NEURAL FATAL]:", error.message);
    res.status(500).json({ error: "Neural synthesis pipeline failure." });
  }
});

const PORT = 5001;
app.listen(PORT, () => console.log(`Neural Studio Server Live & Optimized on port ${PORT} 🚀`));
